# Symfony UX LazyImage

> [!WARNING]
> **Deprecated**: This package has been **deprecated** in 2.x and will be removed in the next major version.

The package has been deprecated in favor of [modern techniques to improve image loading performance](https://web.dev/learn/images/performance-issues) natively supported
by all major browsers (`<img loading="lazy">`).

To keep using BlurHash functionality, you can use the package [kornrunner/php-blurhash](https://github.com/kornrunner/php-blurhash).

---

Symfony UX LazyImage is a Symfony bundle providing utilities to improve
image loading performance. It is part of [the Symfony UX initiative](https://ux.symfony.com/).

It provides two key features:

-   a Stimulus controller to load lazily heavy images, with a placeholder
-   a [BlurHash implementation](https://blurha.sh/) to create data-uri thumbnails for images

**This repository is a READ-ONLY sub-tree split**. See
https://github.com/symfony/ux to create issues or submit pull requests.

## Sponsor

The Symfony UX packages are [backed][1] by [Mercure.rocks][2].

Create real-time experiences in minutes! Mercure.rocks provides a realtime API service
that is tightly integrated with Symfony: create UIs that update in live with UX Turbo,
send notifications with the Notifier component, expose async APIs with API Platform and
create low level stuffs with the Mercure component. We maintain and scale the complex
infrastructure for you!

Help Symfony by [sponsoring][3] its development!

## Resources

-   [Documentation](https://symfony.com/bundles/ux-lazy-image/current/index.html)
-   [Report issues](https://github.com/symfony/ux/issues) and
    [send Pull Requests](https://github.com/symfony/ux/pulls)
    in the [main Symfony UX repository](https://github.com/symfony/ux)

[1]: https://symfony.com/backers
[2]: https://mercure.rocks
[3]: https://symfony.com/sponsor
