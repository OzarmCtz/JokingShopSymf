See @.github/copilot-instructions.md
